// controllers/customerController.js

const bcrypt = require('bcrypt');
const Customer = require('../models/customerSchema.js');
const { createNewToken } = require('../utils/token.js');

const customerRegister = async (req, res) => {
    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPass = await bcrypt.hash(req.body.password, salt);

        const customer = new Customer({
            ...req.body,
            password: hashedPass
        });

        const existingCustomerByEmail = await Customer.findOne({ email: req.body.email });

        if (existingCustomerByEmail) {
            res.send({ message: 'Email already exists' });
        } else {
            let result = await customer.save();
            result.password = undefined;

            const token = createNewToken(result._id);

            result = {
                ...result._doc,
                token: token
            };

            res.send(result);
        }
    } catch (err) {
        res.status(500).json(err);
    }
};

const customerLogIn = async (req, res) => {
    if (req.body.email && req.body.password) {
        let customer = await Customer.findOne({ email: req.body.email });
        if (customer) {
            const validated = await bcrypt.compare(req.body.password, customer.password);
            if (validated) {
                customer.password = undefined;

                const token = createNewToken(customer._id);

                customer = {
                    ...customer._doc,
                    token: token
                };

                res.send(customer);
            } else {
                res.send({ message: "Invalid password" });
            }
        } else {
            res.send({ message: "User not found" });
        }
    } else {
        res.send({ message: "Email and password are required" });
    }
};

const getCartDetail = async (req, res) => {
    try {
        let customer = await Customer.findById(req.params.id);
        if (customer) {
            res.send(customer.cartDetails);
        } else {
            res.send({ message: "No customer found" });
        }
    } catch (err) {
        res.status(500).json(err);
    }
};

const cartUpdate = async (req, res) => {
    try {
        let customer = await Customer.findByIdAndUpdate(req.params.id, req.body, { new: true });
        return res.send(customer.cartDetails);
    } catch (err) {
        res.status(500).json(err);
    }
};

const getCartCount = async (req, res) => {
    try {
        const customer = await Customer.findById(req.params.id);
        if (customer) {
            const totalCartCount = customer.cartDetails.reduce((acc, item) => acc + item.quantity, 0);
            res.send({ totalCartCount });
        } else {
            res.status(404).send({ message: "Customer not found" });
        }
    } catch (err) {
        res.status(500).json(err);
    }
};

module.exports = {
    customerRegister,
    customerLogIn,
    getCartDetail,
    cartUpdate,
    getCartCount, // Exporting the new function
};
